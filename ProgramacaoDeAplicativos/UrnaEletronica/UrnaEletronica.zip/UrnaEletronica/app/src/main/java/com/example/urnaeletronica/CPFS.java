package com.example.urnaeletronica;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CPFS {
    String cpf;

    public CPFS(){
    }

    public CPFS (String cpf){
        this.cpf = cpf;
    }

    public void salvar_cpf(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("CPFS").child(cpf).setValue(this);
    }

    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}
