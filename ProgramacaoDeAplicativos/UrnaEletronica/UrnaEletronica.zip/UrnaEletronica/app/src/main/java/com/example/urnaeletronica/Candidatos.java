package com.example.urnaeletronica;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Candidatos {
    String nome, numero, cargo;
    int contador;

    public Candidatos(String nome, String numero, String cargo, int contador){
        this.nome = nome;
        this.numero = numero;
        this.cargo = cargo;
        this.contador = contador;
    }

    public Candidatos() {}

    public void salvar_presidente(){ // esse método faz a ligação com o banco de dados
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Candidatos").child(cargo).setValue(this);
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNumero() {
        return numero;
    }
    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCargo() {
        return cargo;
    }
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getContador() {
        return contador;
    }
    public void setContador(int contador) {
        this.contador = contador;
    }
}