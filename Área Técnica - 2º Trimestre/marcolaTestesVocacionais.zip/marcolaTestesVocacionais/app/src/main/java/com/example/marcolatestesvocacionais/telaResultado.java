package com.example.marcolatestesvocacionais;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentReference;

public class telaResultado extends AppCompatActivity {
    public static String resultado; // vem da tela dois
    TextView txtResultado;
    static String cpf_String;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_resultado);
        getSupportActionBar().hide();
        txtResultado = findViewById(R.id.resultado);
        mostrarResultado();
        salvarUsuario();

        // Tratamentos para Navigation Bar (setinha de voltar no canto inferior)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //Mostrar o botão
        getSupportActionBar().setHomeButtonEnabled(true);      //Ativar o botão
    }

    @Override
    public void onBackPressed(){ // Botão BACK padrão do android (setinha inferior para voltar)
        Intent main = new Intent (this, MainActivity.class);
        startActivity(main); // o efeito ao pressionar o botão (no caso abre a activity)
        finishAffinity(); // método para matar a activity e não deixa-lá indexada na pilhagem
        return; // na documentação tinha esse return
    }
    public void salvarUsuario(){
        Usuarios user = new Usuarios(cpf_String, resultado);
        user.salvar();
    }
    public void mostrarResultado(){
        txtResultado.setText(resultado);
    }
    public void reiniciar(View voltar){
        Intent perguntas = new Intent (this, teladois.class);
        startActivity(perguntas);
        finishAffinity(); // método para matar a activity e não deixa-lá indexada na pilhagem
    }
}