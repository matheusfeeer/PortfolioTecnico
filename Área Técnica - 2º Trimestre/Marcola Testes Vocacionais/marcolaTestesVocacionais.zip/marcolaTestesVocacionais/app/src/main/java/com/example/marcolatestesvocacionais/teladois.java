package com.example.marcolatestesvocacionais;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class teladois extends AppCompatActivity {
    CheckBox p1, p2, p3, p4, p5;
    String b1, b2, b3, b4, b5, resultado, texto;
    int es, as, dg, si, cd;
    Button avancar;
    TextView txtBalao;

    //ES : Engenharia de software
    //AS : Análise de sistemas
    //DG : Design gráfico
    //SI : Suporte de informática
    //CD : Ciências de dados

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teladois);
        getSupportActionBar().hide();
        avancar = findViewById(R.id.botaoAvancar);
        txtBalao = findViewById(R.id.textoPergunta);
        texto = txtBalao.getText().toString();
        texto = "O que você\ngosta de fazer?";
        txtBalao.setText(texto);

        p1 = findViewById(R.id.p1);
        p2 = findViewById(R.id.p2);
        p3 = findViewById(R.id.p3);
        p4 = findViewById(R.id.p4);
        p5 = findViewById(R.id.p5);

        b1 = p1.getText().toString();
        b2 = p2.getText().toString();
        b3 = p3.getText().toString();
        b4 = p4.getText().toString();
        b5 = p5.getText().toString();

        b1 = "Ser uma pessoa realista"; //definindo uma string
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Ser uma pessoa intelectual";
        p2.setText(b2);

        b3 = "Ser uma pessoa cautelosa";
        p3.setText(b3);

        b4 = "Ser uma pessoa bem vestida";
        p4.setText(b4);

        b5 = "Ser uma pessoa\ndisciplinada";
        p5.setText(b5);

        // Tratamentos para Navigation Bar (setinha de voltar no canto inferior)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //Mostrar o botão
        getSupportActionBar().setHomeButtonEnabled(true);      //Ativar o botão
    }

    @Override
    public void onBackPressed(){ //Botão BACK padrão do android (setinha inferior para voltar)
        Intent main = new Intent (this, MainActivity.class);
        startActivity(main); // o efeito ao pressionar o botão (no caso abre a activity)
        finishAffinity(); // método para matar a activity e não deixa-lá indexada na pilhagem
        return; // na documentação tinha esse return
    }

    public void reiniciar(View voltar){ // volta para a primeira tela de assinalar
        Intent v = new Intent(this, teladois.class);
        startActivity(v);
    }

    public void mudaTelaResultado(){
        Intent resultados = new Intent(this, telaResultado.class);
        startActivity(resultados);
    }

    public void calcularResultado(){
        // as, es, dg, si, cd
        if (as > es && as > si && as > dg && as > cd){
            resultado = "Análise de Sistemas";
        }
        else if (es > as && es > si && es > dg && es > cd){
            resultado = "Engenharia de\nSoftware";
        }
        else if (si > as && si > es && si > dg && si > cd){
            resultado = "Suporte de\nInformática";
        }
        else if (dg > as && dg > es && dg > si && dg > cd){
            resultado = "Design Gráfico";
        }
        else if (cd > as && cd > es && cd > si && cd > dg){
            resultado = "Ciência de Dados";
        }

        // Tratar os empates de 2 carreiras
        else if (as == es || as == dg || as == si || as == cd){ // Empates de Análise de Sistemas
            if (as == es){
                resultado = "Empate entre\nAnálise de\nSistemas e\nEngenharia de\nSoftware.";
            }
            else if (as == dg){
                resultado = "Empate entre\nAnálise de\nSistemas e\nDesign Gráfico.";
            }
            else if (as == si){
                resultado = "Empate entre\nAnálise de\nSistemas e\nSuporte de\nInformática.";
            }
            else{
                resultado = "Empate entre\nAnálise de\nSistemas e\nCiência de Dados.";
            }
        }
        else if(es == dg || es == si || es == cd){ // Empates de Engenharia de Software
            if (es == dg){
                resultado = "Empate entre\nEngenharia de\nSoftware e\nDesign Gráfico.";
            }
            else if (es == si){
                resultado = "Empate entre\nEngenharia de\nSoftware e\nSuporte de\nInformática.";
            }
            else{
                resultado = "Empate entre\nEngenharia de\nSoftware e\nCiência de Dados.";
            }
        }
        else if (dg == si || dg == cd){ // Empates de Design Gráfico
            if (dg == si){
                resultado = "Empate entre\nDesign Gráfico e\nSuporte de\nInformática.";
            }
            else{
                resultado = "Empate entre\nDesign Gráfico e\nCiência de Dados.";
            }
        }
        else if (si == cd){
            resultado = "Empate entre\nSuporte de\nInformática e\nCiência de Dados.";
        }
        telaResultado.resultado = resultado;
    }
    public View.OnClickListener contarEAvancarQuinze(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Estratégias de compra\ne venda"; //definindo uma string - Perguntas 71
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Criação, expressão e beleza"; // Pergunta 72
        p2.setText(b2);

        b3 = "Tarefas domésticas"; // Pergunta 73
        p3.setText(b3);

        b4 = "Realizar cálculos\nmatemáticos"; // Pergunta 74
        p4.setText(b4);

        b5 = "Lidar com pessoas\nno cotidiano"; // Pergunta 75
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 71
                    dg += 1;
                }

                if (p2.isChecked()) { // Pergunta 72
                    dg += 1;
                }

                if (p3.isChecked()) { // Pergunta 73
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 74
                    cd += 1;
                }

                if (p5.isChecked()) { // Pergunta 75
                    as += 1;
                    si += 1;
                }
                calcularResultado();
                mudaTelaResultado();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarQuatorze(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Falar em público"; //definindo uma string - Perguntas 66
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Participar de projetos"; // Pergunta 67
        p2.setText(b2);

        b3 = "Gerenciar atividades"; // Pergunta 68
        p3.setText(b3);

        b4 = "Trabalhar com planilhas"; // Pergunta 69
        p4.setText(b4);

        b5 = "Pensar em novos meios\npara realizar tarefas"; // Pergunta 70
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 66
                    as += 1;
                }

                if (p2.isChecked()) { // Pergunta 67
                    es += 1;
                    as += 1;
                    dg += 1;
                    cd += 1;
                }

                if (p3.isChecked()) { // Pergunta 68
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 69
                    cd += 1;
                }

                if (p5.isChecked()) { // Pergunta 70
                    as += 1;
                }
                contarEAvancarQuinze();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarTreze(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Estruturar projetos"; //definindo uma string - Perguntas 61
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Programar"; // Pergunta 62
        p2.setText(b2);

        b3 = "Trabalhar com números"; // Pergunta 63
        p3.setText(b3);

        b4 = "Tomar decisões baseadas\nem observações"; // Pergunta 64
        p4.setText(b4);

        b5 = "Estetizar objetos\nno dia a dia"; // Pergunta 65
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 61
                    es += 1;
                    dg += 1;
                }

                if (p2.isChecked()) { // Pergunta 62
                    es += 1;
                }

                if (p3.isChecked()) { // Pergunta 63
                    cd += 1;
                }

                if (p4.isChecked()) { // Pergunta 64
                    as += 1;
                }

                if (p5.isChecked()) { // Pergunta 65
                    dg += 1;
                }
                contarEAvancarQuatorze();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarDoze(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Fazer apresentações"; //definindo uma string - Perguntas 56
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Ler manuais de instrução"; // Pergunta 57
        p2.setText(b2);

        b3 = "Usar cálculos para\nresolver soluções"; // Pergunta 58
        p3.setText(b3);

        b4 = "Resolver problemas complexos"; // Pergunta 59
        p4.setText(b4);

        b5 = "Comunicar ideias para as pessoas"; // Pergunta 60
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 56
                    as += 1;
                    dg += 1;
                }

                if (p2.isChecked()) { // Pergunta 57
                    si += 1;
                }

                if (p3.isChecked()) { // Pergunta 58
                    es += 1;
                    cd += 1;
                }

                if (p4.isChecked()) { // Pergunta 59
                    es += 1;
                    si += 1;
                    cd += 1;
                }

                if (p5.isChecked()) { // Pergunta 60
                    dg += 1;
                }
                contarEAvancarTreze();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarOnze(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Ter uma agenda flexível"; //definindo uma string - Perguntas 51
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Ser prudente em suas posições"; // Pergunta 52
        p2.setText(b2);

        b3 = "Chegar em soluções\nbenéficas para todos"; // Pergunta 53
        p3.setText(b3);

        b4 = "Procurar respostas para\nquestões diversas"; // Pergunta 54
        p4.setText(b4);

        b5 = "Trabalhar com pessoas\nde outros países"; // Pergunta 55
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 51
                    dg += 1;
                }

                if (p2.isChecked()) { // Pergunta 52
                    as += 1;
                    dg += 1;
                }

                if (p3.isChecked()) { // Pergunta 53
                    es += 1;
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 54
                    es += 1;
                    si += 1;
                }

                if (p5.isChecked()) { // Pergunta 55
                    es += 1;
                    as += 1;
                    cd += 1;
                }
                contarEAvancarDoze();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarDez(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Interpretar fórmulas"; //definindo uma string - Perguntas 46
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Conduzir o grupo a agir\nem determinada direção"; // Pergunta 47
        p2.setText(b2);

        b3 = "Estar no controle das situações"; // Pergunta 48
        p3.setText(b3);

        b4 = "Comunicar-se com diferentes\ntipos de pessoas"; // Pergunta 49
        p4.setText(b4);

        b5 = "Definir cenários futuros"; // Pergunta 50
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 46
                    es += 1;
                    cd += 1;
                }

                if (p2.isChecked()) { // Pergunta 47
                    es += 1;
                }

                if (p3.isChecked()) { // Pergunta 48
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 49
                    dg += 1;
                }

                if (p5.isChecked()) { // Pergunta 50
                    as += 1;
                }
                contarEAvancarOnze();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarNove(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Trabalhar no computador"; //definindo uma string - Perguntas 41
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Prestar atenção à detalhes"; // Pergunta 42
        p2.setText(b2);

        b3 = "Adaptar-se à mudanças"; // Pergunta 43
        p3.setText(b3);

        b4 = "Comparar preços"; // Pergunta 44
        p4.setText(b4);

        b5 = "Tomar decisões"; // Pergunta 45
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 41
                    es += 1;
                    as += 1;
                    dg += 1;
                    cd += 1;
                    si += 1;
                }

                if (p2.isChecked()) { // Pergunta 42
                    as += 1;
                }

                if (p3.isChecked()) { // Pergunta 43
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 44
                    cd += 1;
                }

                if (p5.isChecked()) { // Pergunta 45
                    dg += 1;
                    es += 1;
                }
                contarEAvancarDez();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarOito(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Fazer trabalhos\nque exigem precisão"; //definindo uma string - Perguntas 36
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Resolver problemas técnicos"; // Pergunta 37
        p2.setText(b2);

        b3 = "Analisar escopos\npara propor ações"; // Pergunta 38
        p3.setText(b3);

        b4 = "Atividades que exigem longos períodos\nde concentração"; // Pergunta 39
        p4.setText(b4);

        b5 = "Desenhar logotipos e imagens"; // Pergunta 40
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 36
                    cd += 1;
                    es += 1;
                    as += 1;
                }

                if (p2.isChecked()) { // Pergunta 37
                    si += 1;
                }

                if (p3.isChecked()) { // Pergunta 38
                    as += 1;
                }

                if (p4.isChecked()) { // Pergunta 39
                    es += 1;
                    cd += 1;
                }

                if (p5.isChecked()) { // Pergunta 40
                    dg += 1;
                }
                contarEAvancarNove();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarSete(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Trabalhar com números"; //definindo uma string - Perguntas 31
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Analisar relatórios"; // Pergunta 32
        p2.setText(b2);

        b3 = "Trabalhar em um\nlaboratório"; // Pergunta 33
        p3.setText(b3);

        b4 = "Ir direto ao ponto"; // Pergunta 34
        p4.setText(b4);

        b5 = "Explorar novas tecnologias"; // Pergunta 35
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 31
                    cd += 1;
                }

                if (p2.isChecked()) { // Pergunta 32
                    cd += 1;
                }

                if (p3.isChecked()) { // Pergunta 33
                    es += 1;
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 34
                    as += 1;
                }

                if (p5.isChecked()) { // Pergunta 35
                    es += 1;
                }
                contarEAvancarOito();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarSeis(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Fazer relatórios"; //definindo uma string - Perguntas 26
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Trabalhar em equipe"; // Pergunta 27
        p2.setText(b2);

        b3 = "Analisar informações"; // Pergunta 28
        p3.setText(b3);

        b4 = "Seguir procedimentos\nlógicos"; // Pergunta 29
        p4.setText(b4);

        b5 = "Imaginar e projetar\num produto"; // Pergunta 30
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 26
                    cd += 1;
                }

                if (p2.isChecked()) { // Pergunta 27
                    es += 1;
                }

                if (p3.isChecked()) { // Pergunta 28
                    es += 1;
                    as += 1;
                    cd += 1;
                }

                if (p4.isChecked()) { // Pergunta 29
                    as += 1;
                }

                if (p5.isChecked()) { // Pergunta 30
                    es += 1;
                    dg += 1;
                }
                contarEAvancarSete();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarCinco(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Visualizar objetos em 3D"; //definindo uma string - Perguntas 21
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Usar ferramentas"; // Pergunta 22
        p2.setText(b2);

        b3 = "Operar e/ou fazer\nmanutenção de máquinas"; // Pergunta 23
        p3.setText(b3);

        b4 = "Projetos com foco em resultados"; // Pergunta 24
        p4.setText(b4);

        b5 = "Planejar, organizar\ne fazer registros"; // Pergunta 25
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 21
                    dg += 1;
                }

                if (p2.isChecked()) { // Pergunta 22
                    si += 1;
                }

                if (p3.isChecked()) { // Pergunta 23
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 24
                    es += 1;
                    as += 1;
                    cd += 1;
                }

                if (p5.isChecked()) { // Pergunta 25
                    cd += 1;
                }
                contarEAvancarSeis();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarQuatro(){
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Fazer atividades\ncom instruções"; //definindo uma string - Perguntas 16
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Evitar tarefas manuais"; // Pergunta 17
        p2.setText(b2);

        b3 = "Evitar ser comandado"; // Pergunta 18
        p3.setText(b3);

        b4 = "Lidar com assuntos\nimportantes"; // Pergunta 19
        p4.setText(b4);

        b5 = "Pensar pouco"; // Pergunta 20
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if (p1.isChecked()) { // Pergunta 16
                    si += 1;
                }

                if (p2.isChecked()) { // Pergunta 17
                    es += 1;
                    as += 1;
                    dg += 1;
                    cd += 1;
                }

                if (p3.isChecked()) { // Pergunta 18
                    dg += 1;
                    si += 1;
                }

                if (p4.isChecked()) { // Pergunta 19
                    es += 1;
                    as += 1;
                    cd += 1;
                    si += 1;
                }

                if (p5.isChecked()) { // Pergunta 20
                    dg += 1;
                }
                contarEAvancarCinco();
            }
        });
        return null;
    }

    public View.OnClickListener contarEAvancarTres() {
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Valorizar sucesso e poder"; //definindo uma string
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Valorizar estudo e reflexão";
        p2.setText(b2);

        b3 = "Valorizar rotina e precisão";
        p3.setText(b3);

        b4 = "Valorizar prazer e emoções";
        p4.setText(b4);

        b5 = "Valorizar o funcionamento\nda empresa";
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (p1.isChecked()) { // Pergunta 11
                    es += 1;
                    cd += 1;
                }

                if (p2.isChecked()) { // Pergunta 12
                    as += 1;
                }

                if (p3.isChecked()) { // Pergunta 13
                    cd += 1;
                }

                if (p4.isChecked()) { // Pergunta 14
                    dg += 1;
                }

                if (p5.isChecked()) { // Pergunta 15
                    si += 1;
                    es += 1;
                }
                contarEAvancarQuatro();
            }
        });
        return null;
    }

    public void contarEAvancarDois () {
        p1.setChecked(false); // desmarcar a checkbox
        p2.setChecked(false); // desmarcar a checkbox
        p3.setChecked(false); // desmarcar a checkbox
        p4.setChecked(false); // desmarcar a checkbox
        p5.setChecked(false); // desmarcar a checkbox

        b1 = "Colocar a mão na massa"; //definindo uma string
        p1.setText(b1); //mudando o texto do checkbox

        b2 = "Aprender";
        p2.setText(b2);

        b3 = "Trazer segurança de dados";
        p3.setText(b3);

        b4 = "Contribuir com a sociedade";
        p4.setText(b4);

        b5 = "Possuir desafios\nao longo da vida";
        p5.setText(b5);

        avancar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (p1.isChecked()) { // Pergunta 6
                    si += 1;
                }

                if (p2.isChecked()) { // Pergunta 7
                    cd += 1;
                }

                if (p3.isChecked()) { // Pergunta 8
                    as += 1;
                    es += 1;
                }

                if (p4.isChecked()) { // Pergunta 9
                    es += 1;
                    as += 1;
                    cd += 1;
                }

                if (p5.isChecked()) { // Pergunta 10
                    es += 1;
                }
                contarEAvancarTres();
            }
        });
    }

    public void contarEAvancarUm (View a){
        as = 0;
        es = 0;
        cd = 0;
        si = 0;
        dg = 0;

        if (p1.isChecked()) {
            as += 1;
        }

        if (p2.isChecked()) {
            es += 1;
            cd += 1;
        }

        if (p3.isChecked()) {
            dg += 1;
            si += 1;
        }

        if (p4.isChecked()) {
            dg += 1;
        }

        if (p5.isChecked()) {
            es += 1;
            as += 1;
            cd += 1;
        }
        contarEAvancarDois();
        return;
    }
}