package com.example.marcolatestesvocacionais;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Usuarios {
    String cpf;
    String resultado;

    public Usuarios(){
    }

    public Usuarios(String cpf, String resultado) {
        this.cpf = cpf;
        this.resultado = resultado;
    }

    public Usuarios(String cpf) {
        this.cpf = cpf;
        this.resultado = resultado;
    }

    public void salvar(){ // esse método faz a ligação com o banco de dados
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Usuários").child(cpf).setValue(this); // CPF é a PK
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getResultado(){
        return resultado;
    }

    public void setResultado(String resultado){
        this.resultado = resultado;
    }
}
