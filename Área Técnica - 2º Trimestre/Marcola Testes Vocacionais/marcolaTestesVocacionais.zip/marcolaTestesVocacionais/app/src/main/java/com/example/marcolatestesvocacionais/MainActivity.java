package com.example.marcolatestesvocacionais;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.math.BigInteger;

public class MainActivity extends AppCompatActivity {

    AlertDialog.Builder alertaInsiraNome;
    EditText cpf;
    Button iniciar;
    String cpf_String, resultado_main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        cpf = findViewById(R.id.inserirCpf); // Encontra o campo responsável por inserir o nome no xml
        iniciar = findViewById(R.id.botaoIniciar); // Encontra o botão de iniciar no xml
        alertaInsiraNome = new AlertDialog.Builder(this);

        // Tratamentos para Navigation Bar (setinha de voltar no canto inferior)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //Mostrar o botão
        getSupportActionBar().setHomeButtonEnabled(true);      //Ativar o botão
    }

    public void mudaTelaResultado() {
        Intent resultado = new Intent(this, telaResultado.class);
        startActivity(resultado);
    }

    public void mudaTelaPerguntas() {
        Intent responder = new Intent(this, teladois.class);
        startActivity(responder);
    }

    public void esconderTeclado(View editText) { // esconde o teclado ao clicar fora do cpf
        InputMethodManager imm = (InputMethodManager) this.getSystemService(this.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
    }

    public void verificacao(View v) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Usuários");
        reference.addValueEventListener(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot){
                cpf_String = cpf.getText().toString();
                boolean isNumeric =  cpf_String.matches("[+-]?\\d*(\\.\\d+)?");
                if (isNumeric == true){
                    for (DataSnapshot d : snapshot.getChildren()) {
                        if (d.getValue(Usuarios.class).getCpf().equals(cpf_String)){
                            resultado_main = d.getValue(Usuarios.class).getResultado();
                            telaResultado.resultado = resultado_main;
                            mudaTelaResultado();
                            break;
                            }else{
                                if (cpf_String.length() == 11){ // caso o nome tenha sido preenchido
                                    telaResultado.cpf_String = cpf_String;
                                    mudaTelaPerguntas();
                                    // não tem que ter break aqui
                                } else{ // caso o campo de nome esteja vazio, vai exibir uma mensagem de erro e não vai mudar a tela
                                    String tituloCPFVazio = "Erro";
                                    String avisoCPFVazio = "Insira um CPF de 11 dígitos.";

                                    cpf.setText(null); // esvazia o que foi preenchido

                                    alertaInsiraNome.setTitle(tituloCPFVazio);
                                    alertaInsiraNome.setMessage(avisoCPFVazio);
                                    alertaInsiraNome.show();
                                    break;
                                }
                            }
                    }
                } if (isNumeric == false){ // verificação se foram digitadas letras no campo cpf
                    String titulo = "ERRO";
                    String mensagem = "Preencha apenas os 11 números de seu CPF";
                    cpf.setText(null);
                    alertaInsiraNome.setTitle(titulo);
                    alertaInsiraNome.setMessage(mensagem);
                    alertaInsiraNome.show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error){}
        });
    }
}